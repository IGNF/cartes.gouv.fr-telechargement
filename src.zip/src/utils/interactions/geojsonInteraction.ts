import { booleanIntersects } from "@turf/turf";
import GeoJSON from "ol/format/GeoJSON";
import { Dalle } from "../../assets/@types/types";
import Vector from "ol/source/Vector";
import VectorLayer from "ol/layer/Vector";
import Style from "ol/style/Style";
import Fill from "ol/style/Fill";
import Stroke from "ol/style/Stroke";
import CircleStyle from "ol/style/Circle";
import { isEmpty } from "ol/extent";
import { Polygon } from "ol/geom";

/**
 * Détecte les dalles qui intersectent avec une géométrie GeoJSON
 * Utilise le même pattern que la sélection par polygone
 * @param geojson - L'objet GeoJSON (Feature ou FeatureCollection)
 * @param dallesLayer - La couche contenant les dalles (VectorTileLayer ou VectorLayer)
 * @param isProduitSelected - Fonction pour vérifier si une dalle est sélectionnée
 * @param addProduit - Fonction pour ajouter une dalle
 * @param removeProduit - Fonction optionnelle pour retirer une dalle
 */
export const selectDallesFromGeoJson = (
  geojson: any,
  dallesLayer: any,
  isProduitSelected: (id: string | number | undefined) => boolean,
  addProduit: (produit: any) => void,
  removeProduit?: (id: string | number | undefined) => void
): void => {
  if (!dallesLayer) {
    console.error("La couche des dalles n'est pas disponible");
    return;
  }

  try {
    const format = new GeoJSON();
    const listAlreadyChecked: Set<string> = new Set();

    // Convertir le GeoJSON en features OpenLayers
    let geoJsonFeatures: any[] = [];
    
    if (geojson.type === "FeatureCollection") {
      geoJsonFeatures = format.readFeatures(geojson);
    } else if (geojson.type === "Feature") {
      geoJsonFeatures = format.readFeatures({ type: "FeatureCollection", features: [geojson] });
    } else {
      throw new Error("Format GeoJSON invalide");
    }

    if (geoJsonFeatures.length === 0) {
      console.warn("Aucune géométrie valide trouvée dans le GeoJSON");
      return;
    }

    console.log(`Traitement de ${geoJsonFeatures.length} géométrie(s) GeoJSON pour trouver les dalles intersectées`);

    // Pour chaque géométrie du GeoJSON - utiliser le MÊME PATTERN que selectedPolygonInteraction
    geoJsonFeatures.forEach((geoJsonFeature: any) => {
      const geoJsonGeometry = geoJsonFeature.getGeometry();
      const geoJsonExtent = geoJsonGeometry.getExtent();

      console.log("Recherche des dalles dans l'étendue:", geoJsonExtent);

      // Récupérer les dalles dans l'étendue - EXACTEMENT comme selectedPolygonInteraction le fait
      const dallesInExtent = dallesLayer.getFeaturesInExtent(geoJsonExtent);
      
      console.log(`getFeaturesInExtent retourné ${dallesInExtent.length} features`);

      if (dallesInExtent.length === 0) {
        console.warn("Aucune dalle trouvée dans l'étendue du GeoJSON");
        return;
      }

      console.log(`${dallesInExtent.length} dalle(s) trouvée(s) dans l'étendue`);

      // Vérifier l'intersection avec chaque dalle - MÊME PATTERN que selectedPolygonInteraction
      dallesInExtent.forEach((dalleFeature: any) => {
        const properties = dalleFeature.getProperties();
        const dalleId = properties.id;

        // Éviter de vérifier plusieurs fois la même dalle
        if (listAlreadyChecked.has(dalleId)) {
          return;
        }
        listAlreadyChecked.add(dalleId);

        try {
          // Créer la géométrie de la dalle en tant que polygone (MÊME CODE que selectedPolygonInteraction)
          const featureExtent = dalleFeature.getGeometry().getExtent();
          const coords = [
            [
              [featureExtent[0], featureExtent[1]],
              [featureExtent[0], featureExtent[3]],
              [featureExtent[2], featureExtent[3]],
              [featureExtent[2], featureExtent[1]],
              [featureExtent[0], featureExtent[1]], // Retour au point initial
            ],
          ];

          const polygon = new Polygon(coords);

          // Vérifier si le polygone GeoJSON intersecte l'entité (MÊME CODE que selectedPolygonInteraction)
          if (
            booleanIntersects(
              format.writeGeometryObject(polygon.getSimplifiedGeometry()),
              format.writeGeometryObject(geoJsonGeometry)
            )
          ) {
            const dalle: Dalle = {
              name: properties.name,
              url: properties.url,
              id: properties.id,
              timestamp: new Date(properties.timestamp).getTime(),
              metadata: properties.metadata,
            };

            if (!isProduitSelected(dalle.id)) {
              addProduit(dalle);
              console.log(`Dalle sélectionnée: ${dalle.name}`);
            } else {
              // Optionnel: déselectionner si elle était déjà sélectionnée
              if (removeProduit) {
                removeProduit(dalle.id);
                console.log(`Dalle désélectionnée: ${dalle.name}`);
              }
            }
          }
        } catch (error) {
          console.warn(`Erreur lors du traitement de la dalle ${dalleId}:`, error);
        }
      });
    });

    console.log(`Sélection terminée. ${listAlreadyChecked.size} dalle(s) vérifiée(s)`);
  } catch (error) {
    console.error("Erreur lors de la sélection des dalles intersectées:", error);
  }
};

/**
 * Crée une couche visuelle pour afficher le GeoJSON importé
 * @param geojson - L'objet GeoJSON
 * @param map - L'instance de la carte OpenLayers
 * @returns L'ID de la couche créée
 */
/**
 * Crée une couche visuelle pour afficher le GeoJSON importé
 * @param geojson - L'objet GeoJSON
 * @param map - L'instance de la carte OpenLayers
 * @returns L'ID de la couche créée
 */
export const addGeoJsonLayerToMap = (geojson: any, map: any): string => {
  const format = new GeoJSON();
  const layerId = `imported-geojson-${Date.now()}`;

  try {
    if (!map || !map.getView()) {
      throw new Error("Carte non initialisée");
    }

    // Créer une source vectorielle à partir du GeoJSON
    const source = new Vector({
      features: format.readFeatures(geojson, {
        featureProjection: map.getView().getProjection(),
      }),
    });

    if (!source || source.getFeatures().length === 0) {
      throw new Error("Aucune géométrie valide trouvée dans le GeoJSON");
    }

    console.log(`Chargement de ${source.getFeatures().length} features du GeoJSON`);

    // Créer une couche avec un style spécifique
    const layer = new VectorLayer({
      source: source,
      style: new Style({
        fill: new Fill({
          color: "rgba(0, 150, 255, 0.15)",
        }),
        stroke: new Stroke({
          color: "#0096FF",
          width: 3,
        }),
        image: new CircleStyle({
          radius: 6,
          fill: new Fill({
            color: "#0096FF",
          }),
        }),
      }),
    });

    // Ajouter la couche à la carte
    map.addLayer(layer);
    console.log("Couche GeoJSON ajoutée à la carte");

    // Zoomer sur la couche
    const extent = source.getExtent();
    if (extent && !isEmpty(extent)) {
      console.log("Zoom sur l'étendue du GeoJSON", extent);
      map.getView().fit(extent, {
        padding: [50, 50, 50, 50],
        duration: 1000,
      });
    } else {
      console.warn("Étendue invalide pour le GeoJSON");
    }

    return layerId;
  } catch (error) {
    console.error("Erreur lors de l'ajout du GeoJSON à la carte:", error);
    throw error instanceof Error ? error : new Error("Impossible d'afficher le GeoJSON sur la carte");
  }
};
