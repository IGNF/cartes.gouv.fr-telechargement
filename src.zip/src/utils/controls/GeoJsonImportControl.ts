import Control from "ol/control/Control";
import { Map } from "ol";
import { selectDallesFromGeoJson, addGeoJsonLayerToMap } from "../interactions/geojsonInteraction";

/**
 * Contrôle OpenLayers pour importer et traiter les fichiers GeoJSON
 */
export class GeoJsonImportControl extends Control {
  private fileInput: HTMLInputElement;
  private dropZone: HTMLDivElement;
  private isProduitSelected: (id: string | number | undefined) => boolean;
  private addProduit: (produit: any) => void;
  private removeProduit?: (id: string | number | undefined) => void;
  private mapInstance: Map | null = null;

  constructor(
    isProduitSelected: (id: string | number | undefined) => boolean,
    addProduit: (produit: any) => void,
    removeProduit?: (id: string | number | undefined) => void
  ) {
    const element = document.createElement("div");
    element.className = "ol-geojson-import ol-unselectable ol-control";

    super({ element });

    this.isProduitSelected = isProduitSelected;
    this.addProduit = addProduit;
    this.removeProduit = removeProduit;

    // Créer l'input fichier
    this.fileInput = document.createElement("input");
    this.fileInput.type = "file";
    this.fileInput.accept = ".geojson,.json";
    this.fileInput.style.display = "none";
    document.body.appendChild(this.fileInput);

    // Créer la zone de dépôt
    this.dropZone = document.createElement("div");
    this.dropZone.className = "ol-geojson-import__drop-zone";
    this.dropZone.title = "Importer un GeoJSON";
    this.dropZone.innerHTML = '<span class="fr-icon-upload-line"></span>';

    // Événements
    this.dropZone.addEventListener("click", () => this.fileInput.click());
    this.dropZone.addEventListener("dragover", (e) => this.handleDragOver(e));
    this.dropZone.addEventListener("dragleave", (e) => this.handleDragLeave(e));
    this.dropZone.addEventListener("drop", (e) => this.handleDrop(e));
    this.fileInput.addEventListener("change", (e) => this.handleFileSelect(e));

    element.appendChild(this.dropZone);
  }

  /**
   * Définit l'instance de la carte (appelée automatiquement par OpenLayers)
   */
  setMap(map: Map | null): void {
    super.setMap(map);
    if (map) {
      this.mapInstance = map;
    }
  }

  private handleDragOver(e: DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    this.dropZone.classList.add("drag-over");
  }

  private handleDragLeave(e: DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    this.dropZone.classList.remove("drag-over");
  }

  private handleDrop(e: DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    this.dropZone.classList.remove("drag-over");

    const files = e.dataTransfer?.files;
    if (files && files.length > 0) {
      const file = files[0];
      if (file.name.endsWith(".geojson") || file.name.endsWith(".json")) {
        this.processFile(file);
      } else {
        this.showNotification("Erreur", "Veuillez sélectionner un fichier GeoJSON ou JSON valide");
      }
    }
  }

  private handleFileSelect(e: Event) {
    const input = e.target as HTMLInputElement;
    const file = input.files?.[0];
    if (file) {
      this.processFile(file);
    }
  }

  private processFile(file: File) {
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const geojson = JSON.parse(content);

        // Valider le GeoJSON
        if (!this.isValidGeoJson(geojson)) {
          throw new Error("Format GeoJSON invalide");
        }

        // Vérifier que la carte est initialisée
        if (!this.mapInstance) {
          throw new Error("La carte n'est pas initialisée");
        }

        // Ajouter le GeoJSON à la carte
        console.log("Ajout du GeoJSON à la carte...");
        addGeoJsonLayerToMap(geojson, this.mapInstance);
        console.log("GeoJSON ajouté avec succès");

        // Récupérer la couche de sélection depuis la map
        const selectionLayer = this.mapInstance.getLayers().getArray().find((layer: any) => {
          return layer.get && layer.get("name") === "selectionProduitLayer";
        });

        if (!selectionLayer) {
          console.warn("Couche de sélection non trouvée dans la map");
          return;
        }

        console.log("Couche de sélection trouvée:", selectionLayer);

        // Sélectionner les dalles qui intersectent
        const performSelection = () => {
          console.log("Exécution de la sélection des dalles...");
          selectDallesFromGeoJson(
            geojson,
            selectionLayer,
            this.isProduitSelected,
            this.addProduit,
            this.removeProduit
          );
        };

        // Attendre que les tuiles se chargent - le zoom de addGeoJsonLayerToMap les charge
        // On ajoute un délai pour laisser les tuiles se charger
        console.log("Attente du chargement des tuiles avant sélection (2s)...");
        setTimeout(() => {
          performSelection();
        }, 2000);

        this.showNotification(
          "Succès",
          "GeoJSON importé avec succès.",
          "success"
        );
      } catch (error) {
        const message = error instanceof Error ? error.message : "Erreur lors du traitement du fichier";
        this.showNotification("Erreur", message, "error");
        console.error("Erreur import GeoJSON:", error);
      }
    };

    reader.onerror = () => {
      this.showNotification("Erreur", "Erreur lors de la lecture du fichier");
    };

    reader.readAsText(file);
    this.fileInput.value = "";
  }

  private isValidGeoJson(geojson: any): boolean {
    if (!geojson || typeof geojson !== "object") {
      return false;
    }

    return (
      (geojson.type === "FeatureCollection" && Array.isArray(geojson.features)) ||
      (geojson.type === "Feature" && geojson.geometry)
    );
  }

  private showNotification(title: string, message: string, type: "success" | "error" = "error") {
    const notification = document.createElement("div");
    notification.className = `geojson-notification geojson-notification--${type}`;
    notification.innerHTML = `
      <div class="geojson-notification__content">
        <strong>${title}</strong>
        <p>${message}</p>
      </div>
    `;

    document.body.appendChild(notification);

    setTimeout(() => notification.classList.add("show"), 10);
    setTimeout(() => {
      notification.classList.remove("show");
      setTimeout(() => document.body.removeChild(notification), 300);
    }, 3000);
  }
}

/**
 * Fonction utilitaire pour ajouter le contrôle à une carte
 */
export function addGeoJsonImportControl(
  map: Map,
  isProduitSelected: (id: string | number | undefined) => boolean,
  addProduit: (produit: any) => void,
  removeProduit?: (id: string | number | undefined) => void
) {
  const control = new GeoJsonImportControl(
    isProduitSelected,
    addProduit,
    removeProduit
  );
  map.addControl(control);
  return control;
}
