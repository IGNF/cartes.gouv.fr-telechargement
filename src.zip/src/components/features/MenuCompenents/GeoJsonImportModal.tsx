import { createModal } from "@codegouvfr/react-dsfr/Modal";
import { useState, useRef } from "react";
import { Button } from "@codegouvfr/react-dsfr/Button";
import useMapStore from "../../../hooks/store/useMapStore";
import { useDalleStore } from "../../../hooks/store/useDalleStore";
import { selectDallesFromGeoJson, addGeoJsonLayerToMap } from "../../../utils/interactions/geojsonInteraction";
import GeoJsonImportInfo from "./GeoJsonImportInfo";
import "./styles/GeoJsonImportModal.css";

export const geoJsonImportModal = createModal({
  id: "geojson-import-modal",
  isOpenedByDefault: false,
});

interface GeoJsonFeature {
  type: "Feature" | "FeatureCollection";
  geometry: any;
  properties?: any;
}

const GeoJsonImportModal = () => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [showInfoPanel, setShowInfoPanel] = useState(false);
  const mapInstance = useMapStore((state) => state.mapInstance);
  const isProduitSelected = useDalleStore((state) => state.isProduitSelected);
  const addProduit = useDalleStore((state) => state.addProduit);
  const produitLayer = useDalleStore((state) => state.produitLayer);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setError(null);
    handleFileImport(file);
  };

  const handleFileImport = (file: File) => {
    setIsLoading(true);
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const geojson = JSON.parse(content) as GeoJsonFeature;

        // Valider le format GeoJSON
        if (!isValidGeoJson(geojson)) {
          throw new Error(
            "Format GeoJSON invalide. Le fichier doit contenir une Feature ou FeatureCollection."
          );
        }

        // Traiter le GeoJSON et l'ajouter à la carte
        processGeoJson(geojson);
        setError(null);
        
        // Afficher le panneau d'info et auto-fermer la modal après 2 secondes
        setShowInfoPanel(true);
        setTimeout(() => {
          geoJsonImportModal.close();
          setSuccessMessage(null);
        }, 2000);
      } catch (err) {
        const errorMessage =
          err instanceof Error ? err.message : "Erreur lors de la lecture du fichier";
        setError(errorMessage);
      } finally {
        setIsLoading(false);
        // Réinitialiser l'input
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
      }
    };

    reader.onerror = () => {
      setError("Erreur lors de la lecture du fichier");
      setIsLoading(false);
    };

    reader.readAsText(file);
  };

  const isValidGeoJson = (geojson: any): boolean => {
    if (!geojson || typeof geojson !== "object") {
      return false;
    }

    return (
      (geojson.type === "FeatureCollection" && Array.isArray(geojson.features)) ||
      (geojson.type === "Feature" && geojson.geometry)
    );
  };

  const processGeoJson = (geojson: GeoJsonFeature) => {
    if (!mapInstance) {
      throw new Error("La carte n'est pas initialisée");
    }

    if (!produitLayer) {
      throw new Error("La couche des dalles n'est pas initialisée");
    }

    // Ajouter la couche GeoJSON à la carte
    addGeoJsonLayerToMap(geojson, mapInstance);

    // Sélectionner les dalles qui intersectent le GeoJSON
    selectDallesFromGeoJson(
      geojson,
      produitLayer,
      (id) => isProduitSelected(id as string),
      addProduit
    );

    setSuccessMessage("GeoJSON importé avec succès. Les dalles intersectées ont été sélectionnées.");
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.classList.add("drag-over");
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.currentTarget.classList.remove("drag-over");
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.classList.remove("drag-over");

    const file = e.dataTransfer.files?.[0];
    if (file && (file.name.endsWith(".geojson") || file.name.endsWith(".json"))) {
      setFileName(file.name);
      handleFileImport(file);
    } else {
      setError(
        "Veuillez déposer un fichier GeoJSON ou JSON valide (.geojson ou .json)"
      );
    }
  };

  return (
    <>
      <geoJsonImportModal.Component
        title="Importer un GeoJSON"
        buttons={[
          {
            doClosesModal: true,
            children: "Annuler",
            priority: "secondary",
          },
        ]}
      >
        <div className="geojson-import-container">
          <div
            className="geojson-drop-zone"
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="drop-zone-content">
              <span className="fr-icon-upload-cloud-line"></span>
              <p className="drop-zone-title">
                Déposez votre fichier GeoJSON ici ou cliquez pour le sélectionner
              </p>
              <p className="drop-zone-subtitle">
                Formats acceptés : .geojson, .json (GeoJSON valide)
              </p>
            </div>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept=".geojson,.json"
            onChange={handleFileSelect}
            style={{ display: "none" }}
            aria-label="Sélectionner un fichier GeoJSON"
            disabled={isLoading}
          />

          {fileName && (
            <div className="import-info">
              <span className="fr-icon-file-line"></span>
              <span>{fileName}</span>
            </div>
          )}

          {successMessage && (
            <div className="import-success">
              <span className="fr-icon-check-line"></span>
              <span>{successMessage}</span>
            </div>
          )}

          {error && <div className="import-error">{error}</div>}

          {isLoading && (
            <div className="import-loading">
              <div className="spinner"></div>
              <p>Traitement du fichier en cours...</p>
            </div>
          )}
        </div>
      </geoJsonImportModal.Component>

      {/* Panneau d'informations des dalles sélectionnées */}
      <GeoJsonImportInfo
        isVisible={showInfoPanel}
        onClose={() => setShowInfoPanel(false)}
      />
    </>
  );
};

export default GeoJsonImportModal;
